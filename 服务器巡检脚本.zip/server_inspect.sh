#!/usr/bin/env bash
#
# server_inspect.sh — 多服务器巡检主控脚本（配置集中化版）
# -----------------------------------------------------
# 功能：
#   - 自动上传 collect.sh 并执行采集
#   - 拉取采集结果
#   - 生成 TXT 三份日志（基础/服务/完整）
#   - 生成 HTML 报告（折叠 + 导航 + 颜色 + CPU/内存图表）
#   - ZIP 自动归档
#   - 全局生产级安全删除机制
#   - [优化] 所有核心配置（前缀、服务器列表）已移至脚本顶部
#

########################################
# 【配置区】所有修改请在此处进行
########################################

# 1. 全局名称前缀变量
# 修改此处即可一键更改所有生成文件/目录的前缀 (例如: "xj_", "inspect_", "db_check_")
NAME_PREFIX="xj_"

# 2. 服务器列表配置
# 格式："名称|IP地址|用户名|密码"
# 每行一个服务器，用括号包裹，双引号包围，末尾加空格或换行
SERVERS=(
  "达梦数据库|192.168.10.131|root|123456"
  "金仓数据库|192.168.10.132|root|123456"
  # 示例：添加新服务器只需复制一行并修改内容
  # "Web服务器|192.168.10.133|root|password123"
)

# 3. 预警阈值配置
MEM_WARN=90   # 内存使用率警告阈值 (%)
DISK_WARN=80  # 磁盘使用率警告阈值 (%)

# 4. 服务端口映射 (用于检测关键端口是否监听)
declare -A SERVICE_PORTS=(
  ["nginx"]="80 443"
  ["redis"]="6379"
  ["mysqld"]="3306"
  ["postgres"]="5432"
  ["dmserver"]="5236"
  ["kingbase"]="54321"
  ["tomcat"]="8080"
)

########################################
# 基本路径变量（必须紧随配置区之后定义）
########################################
BASE_DIR="$(cd "$(dirname "$0")" && pwd)"
DATE_STR=$(date +%Y%m%d)

# 使用变量拼接目录名：前缀_日期巡检日志
LOG_DIR="$BASE_DIR/${NAME_PREFIX}${DATE_STR}巡检日志"

########################################
# safe_rm_dir_v2 — 生产级不可误删删除函数
########################################
safe_rm_dir_v2() {
    local TARGET="$1"

    if [ -z "$TARGET" ]; then
        echo "安全保护：删除目录路径为空，拒绝执行。"
        return 1
    fi

    if [ "$TARGET" = "/" ]; then
        echo "安全保护：拒绝删除根目录 /"
        return 1
    fi

    if [ ! -d "$TARGET" ]; then
        echo "安全保护：路径不存在或不是目录：$TARGET"
        return 1
    fi

    if [ -L "$TARGET" ]; then
        echo "安全保护：检测到符号链接，拒绝删除：$TARGET"
        return 1
    fi

    local REAL
    REAL=$(readlink -f "$TARGET" 2>/dev/null)

    if [ -z "$REAL" ]; then
        echo "安全保护：无法解析真实路径，拒绝删除：$TARGET"
        return 1
    fi

    case "$REAL" in
        "$BASE_DIR"/*)
            ;;
        *)
            echo "安全保护：真实路径不在 BASE_DIR 下，拒绝删除：$REAL"
            return 1
            ;;
    esac

    if [ "$(id -u)" -eq 0 ]; then
        echo "警告：当前以 root 身份运行，删除操作风险极高。"
        echo "目标目录：$REAL"
        read -p "确认要删除该目录吗？输入 YES 才会继续：" CONFIRM
        if [ "$CONFIRM" != "YES" ]; then
            echo "已取消删除操作。"
            return 1
        fi
    fi

    echo "安全删除目录：$REAL"
    rm -rf "$REAL"
    return 0
}

########################################
# safe_rm_file — 安全删除 ZIP 文件
########################################
safe_rm_file() {
    local FILE="$1"

    [ -z "$FILE" ] && echo "安全保护：删除文件路径为空，拒绝执行。" && return 1
    [ ! -f "$FILE" ] && return 0

    # 动态匹配前缀，确保只删除符合当前配置规则的 ZIP
    case "$FILE" in
        *zip日志备份/${NAME_PREFIX}*.zip)
            echo "安全删除文件：$FILE"
            rm -f "$FILE"
            ;;
        *)
            echo "安全保护：拒绝删除文件：$FILE"
            return 1
            ;;
    esac
}

########################################
# 每次执行前清理当天旧目录（安全）
########################################
if [ -d "$LOG_DIR" ]; then
    echo "检测到当天已有巡检目录，正在安全清理：$LOG_DIR"
    safe_rm_dir_v2 "$LOG_DIR"
fi

mkdir -p "$LOG_DIR"

########################################
# TXT / HTML 日志文件路径定义
########################################
XT_LOG="$LOG_DIR/${NAME_PREFIX}server_xt_log_hlw.txt"
FW_LOG="$LOG_DIR/${NAME_PREFIX}server_fw_log_hlw.txt"
ALL_LOG="$LOG_DIR/${NAME_PREFIX}server_all_log_hlw.txt"
HTML_LOG="$LOG_DIR/${NAME_PREFIX}server_report_hlw.html"

########################################
# expect 封装函数（上传、执行、拉取）
########################################
upload_collect() {
  local host="$1" user="$2" pass="$3"
  expect <<EOF >/dev/null 2>&1
    set timeout 30
    spawn scp -o StrictHostKeyChecking=no "$BASE_DIR/collect.sh" $user@$host:/tmp/collect.sh
    expect {
      "*yes/no*" { send "yes\r"; exp_continue }
      "*assword*" { send "$pass\r"; exp_continue }
      eof
    }
EOF
}

run_collect() {
  local host="$1" user="$2" pass="$3"
  expect <<EOF >/dev/null 2>&1
    set timeout 60
    spawn ssh -o StrictHostKeyChecking=no $user@$host "bash /tmp/collect.sh"
    expect {
      "*yes/no*" { send "yes\r"; exp_continue }
      "*assword*" { send "$pass\r"; exp_continue }
      eof
    }
EOF
}

pull_files() {
  local host="$1" user="$2" pass="$3"
  expect <<EOF >/dev/null 2>&1
    set timeout 60
    spawn scp -o StrictHostKeyChecking=no -r $user@$host:/tmp/health_collect "$LOG_DIR/${host}_health_collect"
    expect {
      "*yes/no*" { send "yes\r"; exp_continue }
      "*assword*" { send "$pass\r"; exp_continue }
      eof
    }
EOF
}

########################################
# 初始化 TXT 日志头
########################################
{
  echo "系统基础信息日志"
  echo "生成时间: $(date)"
  echo "==============================================="
} > "$XT_LOG"

{
  echo "服务/数据库/端口/TOP 等信息日志"
  echo "生成时间: $(date)"
  echo "==============================================="
} > "$FW_LOG"

{
  echo "完整巡检日志"
  echo "生成时间: $(date)"
  echo "==============================================="
} > "$ALL_LOG"

########################################
# 初始化 HTML 报告头部
########################################
cat > "$HTML_LOG" <<EOF
<!DOCTYPE html>
<html lang="zh-CN">
<head>
<meta charset="UTF-8">
<title>多服务器巡检报告 ${NAME_PREFIX}${DATE_STR}</title>

<style>
body { font-family: Consolas, Menlo, monospace; background:#f5f5f5; margin:0; padding:0; }
header { background:#2c3e50; color:#ecf0f1; padding:10px 20px; }
h1 { margin:0; font-size:20px; }
.container { padding:20px; }
.nav { background:#ecf0f1; padding:10px; margin-bottom:20px; border-radius:4px; }
.nav a { margin-right:15px; text-decoration:none; color:#2980b9; }
.nav a:hover { text-decoration:underline; }
.server-block { background:#ffffff; border-radius:6px; margin-bottom:20px; padding:15px 20px; box-shadow:0 1px 3px rgba(0,0,0,0.1); }
.server-title { font-size:18px; margin-bottom:10px; }
.tag-info { color:#27ae60; font-weight:bold; }
.tag-warn { color:#c0392b; font-weight:bold; }
details { margin:8px 0; }
summary { cursor:pointer; font-weight:bold; }
pre { background:#fafafa; border:1px solid #e1e1e1; padding:8px; border-radius:4px; overflow-x:auto; }
.module-title { color:#34495e; }
.chart-container { background:#ffffff; border-radius:6px; padding:15px 20px; box-shadow:0 1px 3px rgba(0,0,0,0.1); margin-bottom:20px; }
</style>

<script>
var serverLabels = [];
var cpuUsage = [];
var memUsage = [];
</script>

</head>
<body>
<header>
  <h1>多服务器巡检报告 - ${NAME_PREFIX}${DATE_STR}</h1>
</header>

<div class="container">

<div class="nav">
  <strong>服务器导航：</strong>
EOF

########################################
# 生成 HTML 导航栏
########################################
SERVER_INDEX=0
for ITEM in "${SERVERS[@]}"; do
  IFS="|" read -r NAME HOST USER PASS <<< "$ITEM"
  echo "  <a href=\"#server_$SERVER_INDEX\">$NAME ($HOST)</a>" >> "$HTML_LOG"
  SERVER_INDEX=$((SERVER_INDEX+1))
done

echo "</div>" >> "$HTML_LOG"

########################################
# 主循环：逐台服务器巡检
########################################
SERVER_INDEX=0

for ITEM in "${SERVERS[@]}"; do
  IFS="|" read -r NAME HOST USER PASS <<< "$ITEM"
  SERVER_ID="server_$SERVER_INDEX"
  SERVER_INDEX=$((SERVER_INDEX+1))

  echo "开始巡检：$NAME ($HOST)"

  # 1. 上传采集脚本
  upload_collect "$HOST" "$USER" "$PASS"

  # 2. 执行采集脚本
  run_collect "$HOST" "$USER" "$PASS"

  # 3. 准备拉取路径
  LOCAL_DIR="$LOG_DIR/${HOST}_health_collect"

  # 清理旧拉取数据（安全）
  [ -d "$LOCAL_DIR" ] && safe_rm_dir_v2 "$LOCAL_DIR"

  # 4. 拉取结果
  pull_files "$HOST" "$USER" "$PASS"

  # 5. 校验拉取结果
  if [ ! -d "$LOCAL_DIR" ] || [ ! -f "$LOCAL_DIR/hostname.txt" ]; then
      echo "$NAME|$HOST 日志拉取失败" | tee -a "$XT_LOG" "$FW_LOG" "$ALL_LOG"

      {
        echo "<div class=\"server-block\" id=\"$SERVER_ID\">"
        echo "  <div class=\"server-title\">$NAME ($HOST)</div>"
        echo "  <div class=\"tag-warn\">日志拉取失败，未生成任何巡检数据</div>"
        echo "</div>"
      } >> "$HTML_LOG"

      continue
  fi

  # 6. 定义采集文件路径变量
  HOSTNAME="$LOCAL_DIR/hostname.txt"
  IPADDR="$LOCAL_DIR/ip_addr.txt"
  UPTIME="$LOCAL_DIR/uptime.txt"
  KERNEL="$LOCAL_DIR/kernel.txt"
  ARCH="$LOCAL_DIR/arch.txt"
  DATETIME="$LOCAL_DIR/datetime.txt"
  TIMEDATECTL="$LOCAL_DIR/timedatectl.txt"
  WHOLOG="$LOCAL_DIR/who.txt"

  FREE_M="$LOCAL_DIR/free_m.txt"
  FREE_H="$LOCAL_DIR/free_h.txt"
  DF_H="$LOCAL_DIR/df_h.txt"
  LCPU="$LOCAL_DIR/lscpu.txt"
  REL="$LOCAL_DIR/release.txt"

  TOP="$LOCAL_DIR/top.txt"
  PORTS="$LOCAL_DIR/ports.txt"
  SERVICES="$LOCAL_DIR/services.txt"
  DBINFO="$LOCAL_DIR/databases.txt"

  ########################################
  # 预警判断逻辑
  ########################################
  MEM_WARN_FLAG="INFO"
  if awk -v th="$MEM_WARN" '/Mem:/ {total=$2; used=$3; if(total>0 && used*100>total*th) exit 0; exit 1}' "$FREE_M"; then
    MEM_WARN_FLAG="WARN"
  fi

  DISK_WARN_FLAG="INFO"
  if awk -v th="$DISK_WARN" 'NR>1 {gsub("%","",$5); if($5>th) exit 0} END{exit 1}' "$DF_H"; then
    DISK_WARN_FLAG="WARN"
  fi

  PORT_WARN_FLAG="INFO"
  while read -r svc status; do
    [ "$status" != "running" ] && continue
    for p in ${SERVICE_PORTS[$svc]}; do
      if ! grep -q ":$p " "$PORTS"; then
        PORT_WARN_FLAG="WARN"
      fi
    done
  done < "$SERVICES"

  ########################################
  # 计算图表数据 (CPU/Mem)
  ########################################
  MEM_PCT=$(awk '/Mem:/ {if($2>0){printf "%.1f", $3*100/$2}else{print "0.0"}}' "$FREE_M")

  LOAD1=$(awk -F'load average: ' '{print $2}' "$UPTIME" | cut -d',' -f1 | tr -d ' ')
  CORES=$(grep -E '^CPU\(s\):' "$LCPU" | awk '{print $2}')
  [ -z "$CORES" ] && CORES=1
  [ -z "$LOAD1" ] && LOAD1=0
  CPU_PCT=$(awk -v l="$LOAD1" -v c="$CORES" 'BEGIN{if(c<=0)c=1; p=l/c*100; if(p>100)p=100; if(p<0)p=0; printf "%.1f", p}')

  # 写入 JS 数组
  cat >> "$HTML_LOG" <<EOF
<script>
serverLabels.push("$NAME($HOST)");
cpuUsage.push($CPU_PCT);
memUsage.push($MEM_PCT);
</script>
EOF

  ########################################
  # 生成 TXT：基础信息日志
  ########################################
  {
    echo "服务器: $NAME"
    echo "IP: $HOST"
    echo "----- 主机名 -----" && cat "$HOSTNAME"
    echo "----- IP 地址 -----" && cat "$IPADDR"
    echo "----- 运行时长 -----" && cat "$UPTIME"
    echo "----- 内核版本 -----" && cat "$KERNEL"
    echo "----- 系统架构 -----" && cat "$ARCH"
    echo "----- 系统时间 -----" && cat "$DATETIME"
    echo "----- 时间同步 -----" && cat "$TIMEDATECTL"
    echo "----- 登录用户 -----" && cat "$WHOLOG"
    echo "----- 系统版本 -----" && cat "$REL"
    echo "----- CPU 信息 -----" && cat "$LCPU"
    echo "----- 内存信息 -----" && cat "$FREE_H"
    echo "----- 磁盘信息 -----" && cat "$DF_H"
    for i in {1..5}; do echo; done
  } >> "$XT_LOG"

  ########################################
  # 生成 TXT：服务/端口日志
  ########################################
  {
    echo "服务器: $NAME"
    echo "IP: $HOST"
    echo "预警状态 -> 内存:$MEM_WARN_FLAG | 磁盘:$DISK_WARN_FLAG | 端口:$PORT_WARN_FLAG"
    echo "----- 服务状态 -----" && cat "$SERVICES"
    echo "----- 端口监听 -----" && cat "$PORTS"
    echo "----- 数据库识别 -----" && cat "$DBINFO"
    echo "----- TOP (CPU) -----" && cat "$TOP"
    for i in {1..5}; do echo; done
  } >> "$FW_LOG"

  ########################################
  # 生成 TXT：完整日志
  ########################################
  {
    echo "服务器: $NAME"
    echo "IP: $HOST"
    echo "===== 基础信息 ====="
    cat "$HOSTNAME"; cat "$IPADDR"; cat "$UPTIME"; cat "$KERNEL"; cat "$ARCH"
    cat "$DATETIME"; cat "$TIMEDATECTL"; cat "$WHOLOG"; cat "$REL"; cat "$LCPU"
    cat "$FREE_H"; cat "$DF_H"
    echo "===== 服务与进程 ====="
    cat "$SERVICES"; cat "$PORTS"; cat "$DBINFO"; cat "$TOP"
    for i in {1..5}; do echo; done
  } >> "$ALL_LOG"

  ########################################
  # 生成 HTML：服务器详情块
  ########################################
  MEM_CLASS="tag-info"; [ "$MEM_WARN_FLAG" = "WARN" ] && MEM_CLASS="tag-warn"
  DISK_CLASS="tag-info"; [ "$DISK_WARN_FLAG" = "WARN" ] && DISK_CLASS="tag-warn"
  PORT_CLASS="tag-info"; [ "$PORT_WARN_FLAG" = "WARN" ] && PORT_CLASS="tag-warn"

  {
    echo "<div class=\"server-block\" id=\"$SERVER_ID\">"
    echo "  <div class=\"server-title\">$NAME ($HOST)</div>"
    echo "  <div>"
    echo "    内存：<span class=\"$MEM_CLASS\">$MEM_WARN_FLAG</span> | "
    echo "    磁盘：<span class=\"$DISK_CLASS\">$DISK_WARN_FLAG</span> | "
    echo "    端口：<span class=\"$PORT_CLASS\">$PORT_WARN_FLAG</span>"
    echo "  </div>"

    echo "  <details open>"
    echo "    <summary class=\"module-title\">基础系统信息</summary>"
    echo "    <details open><summary>主机/IP/时间/ uptime</summary><pre>"
    cat "$HOSTNAME"; echo "---"; cat "$IPADDR"; echo "---"; cat "$DATETIME"; echo "---"; cat "$UPTIME"
    echo "</pre></details>"
    
    echo "    <details><summary>内核/架构/同步/用户</summary><pre>"
    cat "$KERNEL"; echo "---"; cat "$ARCH"; echo "---"; cat "$TIMEDATECTL"; echo "---"; cat "$WHOLOG"
    echo "</pre></details>"

    echo "    <details><summary>版本/CPU/内存/磁盘</summary><pre>"
    cat "$REL"; echo "---"; cat "$LCPU"; echo "---"; cat "$FREE_H"; echo "---"; cat "$DF_H"
    echo "</pre></details>"
    echo "  </details>"

    echo "  <details>"
    echo "    <summary class=\"module-title\">服务 / 端口 / 数据库 / TOP</summary>"
    echo "    <details open><summary>服务状态</summary><pre>"
    cat "$SERVICES"
    echo "</pre></details>"
    
    echo "    <details><summary>端口监听</summary><pre>"
    cat "$PORTS"
    echo "</pre></details>"

    echo "    <details><summary>数据库识别</summary><pre>"
    cat "$DBINFO"
    echo "</pre></details>"

    echo "    <details><summary>TOP 信息</summary><pre>"
    cat "$TOP"
    echo "</pre></details>"
    echo "  </details>"

    echo "</div>"
  } >> "$HTML_LOG"

done

########################################
# HTML：图表渲染 (Chart.js)
########################################
cat >> "$HTML_LOG" <<'EOF'
<div class="chart-container">
  <h2>CPU / 内存使用率概览</h2>
  <canvas id="cpuMemChart"></canvas>
</div>

<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<script>
var ctx = document.getElementById('cpuMemChart').getContext('2d');
new Chart(ctx, {
    type: 'bar',
    data: {
        labels: serverLabels,
        datasets: [
            {
                label: 'CPU 使用率 (%)',
                data: cpuUsage,
                backgroundColor: 'rgba(231, 76, 60, 0.6)',
                borderColor: 'rgba(192, 57, 43, 1)',
                borderWidth: 1
            },
            {
                label: '内存使用率 (%)',
                data: memUsage,
                backgroundColor: 'rgba(52, 152, 219, 0.6)',
                borderColor: 'rgba(41, 128, 185, 1)',
                borderWidth: 1
            }
        ]
    },
    options: {
        responsive: true,
        scales: {
            y: { beginAtZero: true, max: 100, ticks: { stepSize: 10 } }
        }
    }
});
</script>
EOF

########################################
# HTML 结尾
########################################
cat >> "$HTML_LOG" <<EOF
</div> <!-- container -->
</body>
</html>
EOF

########################################
# ZIP 打包归档
########################################
ZIP_DIR="$BASE_DIR/zip日志备份"
mkdir -p "$ZIP_DIR"

ZIP_NAME="$ZIP_DIR/${NAME_PREFIX}${DATE_STR}巡检日志.zip"

safe_rm_file "$ZIP_NAME"

echo "正在打包 ZIP 文件：$ZIP_NAME"
cd "$BASE_DIR"
zip -r "$ZIP_NAME" "${NAME_PREFIX}${DATE_STR}巡检日志" >/dev/null 2>&1

########################################
# 最终输出
########################################
echo "==============================================="
echo "巡检完成！"
echo "配置前缀：$NAME_PREFIX"
echo "巡检服务器数：${#SERVERS[@]}"
echo "日志目录：$LOG_DIR"
echo "HTML 报告：$HTML_LOG"
echo "ZIP 归档：$ZIP_NAME"
echo "==============================================="