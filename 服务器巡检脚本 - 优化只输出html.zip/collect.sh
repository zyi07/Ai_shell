#!/usr/bin/env bash
#
# collect.sh — 服务器巡检数据采集脚本
# -----------------------------------------------------
# 采集内容：
#   - 基础系统信息（hostname/IP/uptime/kernel/arch/time/who）
#   - CPU / 内存 / 磁盘
#   - CPU详细信息（/proc/cpuinfo 和 nproc）- 用于获取准确核心数
#   - 端口监听
#   - 服务状态
#   - 数据库识别
#   - TOP（按 CPU 排序前 20）
#
# 输出目录：/tmp/health_collect
#

OUT_DIR="/tmp/health_collect"
rm -rf "$OUT_DIR" 2>/dev/null
mkdir -p "$OUT_DIR"

echo "=== 开始采集 ===" > "$OUT_DIR/collect.log"

########################################
# 基础系统信息
########################################
hostname > "$OUT_DIR/hostname.txt" 2>&1
echo "hostname done" >> "$OUT_DIR/collect.log"

ip addr show > "$OUT_DIR/ip_addr.txt" 2>/dev/null || ifconfig > "$OUT_DIR/ip_addr.txt" 2>/dev/null
uptime > "$OUT_DIR/uptime.txt"
uname -r > "$OUT_DIR/kernel.txt"
uname -m > "$OUT_DIR/arch.txt"
date > "$OUT_DIR/datetime.txt"
timedatectl > "$OUT_DIR/timedatectl.txt" 2>/dev/null
who > "$OUT_DIR/who.txt"

lscpu > "$OUT_DIR/lscpu.txt" 2>/dev/null
cat /etc/*release* > "$OUT_DIR/release.txt" 2>/dev/null

free -h > "$OUT_DIR/free_h.txt"
free -m > "$OUT_DIR/free_m.txt"
df -h > "$OUT_DIR/df_h.txt"

########################################
# CPU详细信息 - 关键！用于获取准确核心数
########################################
echo "=== CPU 详细信息 ===" > "$OUT_DIR/cpu_info_summary.txt"
cat /proc/cpuinfo >> "$OUT_DIR/cpuinfo.txt" 2>/dev/null
nproc >> "$OUT_DIR/nproc.txt" 2>/dev/null

# 统计 processor 数量
PROC_COUNT=$(grep -c "^processor" /proc/cpuinfo 2>/dev/null)
echo "processor count: $PROC_COUNT" >> "$OUT_DIR/cpu_info_summary.txt"

# 从 lscpu 获取信息
lscpu | grep -E "^CPU\(s\):|^Core\(s\) per socket:|^Socket\(s\):" >> "$OUT_DIR/cpu_info_summary.txt" 2>/dev/null

echo "cpuinfo done, processor count: $PROC_COUNT" >> "$OUT_DIR/collect.log"

########################################
# TOP（按 CPU 排序前 20）
########################################
ps -eo pid,ppid,user,cmd,%cpu,%mem --sort=-%cpu | head -20 > "$OUT_DIR/top.txt"

########################################
# 端口监听
########################################
if command -v ss >/dev/null 2>&1; then
    ss -tuln > "$OUT_DIR/ports.txt"
else
    netstat -tuln > "$OUT_DIR/ports.txt"
fi

########################################
# 服务状态
########################################
services_list="nginx redis mysqld postgres dmserver kingbase tomcat python node docker httpd apache2 mongod elasticsearch"
: > "$OUT_DIR/services.txt"

for svc in $services_list; do
    if pgrep -x "$svc" >/dev/null 2>&1; then
        echo "$svc running" >> "$OUT_DIR/services.txt"
    fi
done

########################################
# 数据库识别
########################################
DB_OUT="$OUT_DIR/databases.txt"
: > "$DB_OUT"

# 达梦 DM
if pgrep -x "dmserver" >/dev/null 2>&1; then
    echo "发现数据库：达梦 DM" >> "$DB_OUT"
    ps -ef | grep dmserver | grep -v grep >> "$DB_OUT"
    DM_INI=$(ps -ef | grep dmserver | grep -v grep | awk '{for(i=1;i<=NF;i++) if($i ~ /dm.ini/) print $i}')
    [ -n "$DM_INI" ] && echo "配置文件：$DM_INI" >> "$DB_OUT"
    grep -E "PORT_NUM|PATH" "$DM_INI" 2>/dev/null >> "$DB_OUT"
    dmserver -v 2>/dev/null >> "$DB_OUT"
    echo >> "$DB_OUT"
fi

# 金仓 Kingbase
if pgrep -x "kingbase" >/dev/null 2>&1; then
    echo "发现数据库：金仓 Kingbase" >> "$DB_OUT"
    ps -ef | grep kingbase | grep -v grep >> "$DB_OUT"
    KB_CONF=$(ps -ef | grep kingbase | grep -v grep | awk '{for(i=1;i<=NF;i++) if($i ~ /kingbase.conf/) print $i}')
    [ -n "$KB_CONF" ] && echo "配置文件：$KB_CONF" >> "$DB_OUT"
    grep -E "port|data_directory" "$KB_CONF" 2>/dev/null >> "$DB_OUT"
    kingbase --version 2>/dev/null >> "$DB_OUT"
    echo >> "$DB_OUT"
fi

# PostgreSQL
if pgrep -x "postgres" >/dev/null 2>&1; then
    echo "发现数据库：PostgreSQL" >> "$DB_OUT"
    ps -ef | grep postgres | grep -v grep >> "$DB_OUT"
    PGDATA=$(ps -ef | grep postgres | grep -v grep | awk '{for(i=1;i<=NF;i++) if($i=="-D") print $(i+1)}')
    [ -n "$PGDATA" ] && echo "数据目录：$PGDATA" >> "$DB_OUT"
    [ -f "$PGDATA/postgresql.conf" ] && grep -E "^port|data_directory" "$PGDATA/postgresql.conf" >> "$DB_OUT"
    postgres -V 2>/dev/null >> "$DB_OUT"
    echo >> "$DB_OUT"
fi

# MySQL / MariaDB
if pgrep -x "mysqld" >/dev/null 2>&1; then
    echo "发现数据库：MySQL/MariaDB" >> "$DB_OUT"
    ps -ef | grep mysqld | grep -v grep >> "$DB_OUT"
    MY_CNF=$(find /etc -name "my.cnf" 2>/dev/null | head -1)
    [ -n "$MY_CNF" ] && echo "配置文件：$MY_CNF" >> "$DB_OUT"
    grep -E "^port|datadir" "$MY_CNF" 2>/dev/null >> "$DB_OUT"
    mysqld --version 2>/dev/null >> "$DB_OUT"
    echo >> "$DB_OUT"
fi

# Oracle
if pgrep -f "ora_smon" >/dev/null 2>&1; then
    echo "发现数据库：Oracle" >> "$DB_OUT"
    ps -ef | grep ora_smon | grep -v grep >> "$DB_OUT"
    ORACLE_HOME=$(ps -ef | grep ora_smon | grep -v grep | awk -F '_' '{print $1}')
    echo "ORACLE_HOME：$ORACLE_HOME" >> "$DB_OUT"
    echo >> "$DB_OUT"
fi

# Redis
if pgrep -x "redis-server" >/dev/null 2>&1; then
    echo "发现数据库：Redis" >> "$DB_OUT"
    ps -ef | grep redis-server | grep -v grep >> "$DB_OUT"
    REDIS_CONF=$(ps -ef | grep redis-server | grep -v grep | awk '{for(i=1;i<=NF;i++) if($i ~ /redis.conf/) print $i}')
    [ -n "$REDIS_CONF" ] && echo "配置文件：$REDIS_CONF" >> "$DB_OUT"
    grep -E "^port|dir" "$REDIS_CONF" 2>/dev/null >> "$DB_OUT"
    redis-server -v 2>/dev/null >> "$DB_OUT"
    echo >> "$DB_OUT"
fi

# MongoDB
if pgrep -x "mongod" >/dev/null 2>&1; then
    echo "发现数据库：MongoDB" >> "$DB_OUT"
    ps -ef | grep mongod | grep -v grep >> "$DB_OUT"
    MONGO_CONF=$(find /etc -name "mongod.conf" 2>/dev/null | head -1)
    [ -n "$MONGO_CONF" ] && echo "配置文件：$MONGO_CONF" >> "$DB_OUT"
    grep -E "port|dbPath" "$MONGO_CONF" 2>/dev/null >> "$DB_OUT"
    mongod --version 2>/dev/null >> "$DB_OUT"
    echo >> "$DB_OUT"
fi

echo "=== 采集完成 ===" >> "$OUT_DIR/collect.log"
exit 0