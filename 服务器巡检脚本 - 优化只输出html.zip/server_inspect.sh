#!/usr/bin/env bash
#
# server_inspect.sh — 多服务器巡检主控脚本
# =============================================
# 功能说明：
#   1. 自动上传 collect.sh 到目标服务器并执行采集
#   2. 拉取采集结果到本地
#   3. 生成 HTML 报告（带阈值告警：80%页面高亮，90%弹窗）
#   4. 所有报告文件存放在 ${REPORT_DIR} 目录下
#   5. 支持每天覆盖或保留历史记录两种模式
#
# 使用方法：
#   ./server_inspect.sh
#
# 依赖要求：
#   - expect（用于自动SSH/SCP）
#   - 目标服务器需有 bash、awk、grep 等基础命令
#
# =============================================

########################################
# ========== 可配置项（请根据实际情况修改） ==========
########################################

# 报告标题（显示在HTML页面顶部）
REPORT_TITLE="多服务器巡检报告"

# 输出文件前缀（生成的文件名：${PREFIX}_server_report_*.html）
PREFIX="xj"

# 报告存放子目录名称（所有HTML报告将存放在此目录下）
REPORT_DIR_NAME="巡检报告"

# 文件模式设置
# true  = 每天覆盖同名文件（同一天多次运行会覆盖之前的报告）
# false = 保留历史记录（每次运行生成带时间戳的新文件）
OVERWRITE_SAME_DAY=true

# 服务器列表
# 格式： "显示名称|IP地址|用户名|密码"
# 注意：密码中有特殊字符时，需在字符前添加反斜杠转义：$ \ " !
SERVERS=(
  "测试1|192.168.10.161|root|Mjj@r0ot"
  "测试2|192.168.10.162|root|Mjj@r0ot"
)

# ========== 服务/数据库检测配置 ==========
# 方式1：为特定服务器指定需要检测的服务（优先级最高）
CUSTOM_SERVICES=(
  # "测试1|nginx,mysql,redis"
  # "测试2|postgres,tomcat,dmserver"
)

# 方式2：全局默认检测服务列表
DEFAULT_SERVICES=(
  "nginx" "redis" "mysqld" "postgres" "dmserver" "kingbase" 
  "tomcat" "python" "node" "docker" "java" "mongod" 
  "httpd" "apache2" "php-fpm" "elasticsearch" "kibana" 
  "logstash" "rabbitmq" "kafka" "zookeeper" "prometheus" 
  "grafana" "jenkins" "gitlab" "minio" "etcd"
)

# 是否显示未找到服务的信息
SHOW_NO_SERVICES=true

# ========== 阈值设置 ==========
WARN_THRESHOLD=80
CRITICAL_THRESHOLD=90
DISK_WARN_THRESHOLD=80
DISK_CRITICAL_THRESHOLD=90

# ========== 其他配置 ==========
CONNECT_TIMEOUT=30
EXEC_TIMEOUT=60
DEBUG_MODE=false
CONTINUE_ON_ERROR=true
REMOTE_TEMP_DIR="/tmp"
REMOTE_COLLECT_DIR="/tmp/health_collect"
LOCAL_TEMP_BASE="/tmp/health_collect_$$"

########################################
# ========== 配置项说明结束 ==========
########################################

# 调试输出函数
debug_log() {
    if [ "$DEBUG_MODE" = "true" ]; then
        echo "[DEBUG] $1" >&2
    fi
}

# 错误输出函数
error_log() {
    echo "[ERROR] $1" >&2
}

# 信息输出函数
info_log() {
    echo "[INFO] $1"
}

# 获取当前时间
CURRENT_DATETIME=$(date "+%Y-%m-%d %H:%M:%S")
DATE_STR=$(date +%Y%m%d)
BASE_DIR="$(cd "$(dirname "$0")" && pwd)"

# 创建报告存放目录
REPORT_DIR="$BASE_DIR/${REPORT_DIR_NAME}"
mkdir -p "$REPORT_DIR"

# 根据配置决定文件名
if [ "$OVERWRITE_SAME_DAY" = "true" ]; then
    HTML_LOG="$REPORT_DIR/${PREFIX}_server_report_${DATE_STR}.html"
    FILE_MODE="每天覆盖模式"
else
    DATE_TIME_STR=$(date +%Y%m%d_%H%M%S)
    HTML_LOG="$REPORT_DIR/${PREFIX}_server_report_${DATE_TIME_STR}.html"
    FILE_MODE="历史保留模式"
fi

# 构建服务检测命令
build_service_check_cmd() {
    local server_name="$1"
    local services_to_check=()
    
    local found_custom=false
    for custom in "${CUSTOM_SERVICES[@]}"; do
        IFS="|" read -r custom_name service_list <<< "$custom"
        if [ "$custom_name" = "$server_name" ]; then
            IFS=',' read -ra services_to_check <<< "$service_list"
            found_custom=true
            break
        fi
    done
    
    if [ "$found_custom" = false ]; then
        services_to_check=("${DEFAULT_SERVICES[@]}")
    fi
    
    local cmd="echo '=== 服务进程检测 ==='; "
    for svc in "${services_to_check[@]}"; do
        cmd="$cmd if pgrep -x \"$svc\" >/dev/null 2>&1; then echo \"✅ $svc: 运行中\"; else echo \"❌ $svc: 未运行\"; fi; "
    done
    
    cmd="$cmd echo ''; echo '=== 数据库端口检测 ==='; "
    cmd="$cmd if ss -tlnp 2>/dev/null | grep -q ':3306'; then echo '✅ MySQL/MariaDB: 端口3306监听中'; fi; "
    cmd="$cmd if ss -tlnp 2>/dev/null | grep -q ':5432'; then echo '✅ PostgreSQL: 端口5432监听中'; fi; "
    cmd="$cmd if ss -tlnp 2>/dev/null | grep -q ':6379'; then echo '✅ Redis: 端口6379监听中'; fi; "
    cmd="$cmd if ss -tlnp 2>/dev/null | grep -q ':5236'; then echo '✅ 达梦DM: 端口5236监听中'; fi; "
    cmd="$cmd if ss -tlnp 2>/dev/null | grep -q ':54321'; then echo '✅ 金仓Kingbase: 端口54321监听中'; fi; "
    cmd="$cmd if ss -tlnp 2>/dev/null | grep -q ':27017'; then echo '✅ MongoDB: 端口27017监听中'; fi; "
    cmd="$cmd if ss -tlnp 2>/dev/null | grep -q ':8080'; then echo '✅ Tomcat/Jenkins: 端口8080监听中'; fi; "
    
    echo "$cmd"
}

# 清理临时目录函数
cleanup() {
    if [ -d "$LOCAL_TEMP_BASE" ]; then
        debug_log "清理临时目录: $LOCAL_TEMP_BASE"
        rm -rf "$LOCAL_TEMP_BASE" 2>/dev/null
    fi
}
trap cleanup EXIT

########################################
# expect 封装函数
########################################

upload_collect() {
    local host="$1" user="$2" pass="$3"
    debug_log "上传 collect.sh 到 $host"
    
    expect <<EOF >/dev/null 2>&1
        set timeout $CONNECT_TIMEOUT
        spawn scp -o StrictHostKeyChecking=no "$BASE_DIR/collect.sh" $user@$host:$REMOTE_TEMP_DIR/collect.sh
        expect {
            "*yes/no*" { send "yes\r"; exp_continue }
            "*assword*" { send "$pass\r"; exp_continue }
            eof
        }
EOF
    return $?
}

run_collect() {
    local host="$1" user="$2" pass="$3"
    debug_log "在 $host 上执行采集脚本"
    
    expect <<EOF >/dev/null 2>&1
        set timeout $EXEC_TIMEOUT
        spawn ssh -o StrictHostKeyChecking=no $user@$host "bash $REMOTE_TEMP_DIR/collect.sh"
        expect {
            "*yes/no*" { send "yes\r"; exp_continue }
            "*assword*" { send "$pass\r"; exp_continue }
            eof
        }
EOF
    return $?
}

pull_files() {
    local host="$1" user="$2" pass="$3" dest="$4"
    debug_log "从 $host 拉取采集结果到 $dest"
    
    expect <<EOF >/dev/null 2>&1
        set timeout $CONNECT_TIMEOUT
        spawn scp -o StrictHostKeyChecking=no -r $user@$host:$REMOTE_COLLECT_DIR "$dest"
        expect {
            "*yes/no*" { send "yes\r"; exp_continue }
            "*assword*" { send "$pass\r"; exp_continue }
            eof
        }
EOF
    return $?
}

########################################
# 获取主磁盘分区信息（优先根分区，其次容量最大）
########################################
get_main_disk_info() {
    local df_file="$1"
    local target_device=""
    local target_mount=""
    local target_usage=0
    
    local exclude_patterns="tmpfs|devtmpfs|overlay|udev|proc|sysfs|cgroup|debugfs|pstore|securityfs|sunrpc|run"
    
    # 第一遍：查找根分区
    while IFS= read -r line; do
        echo "$line" | grep -q "^Filesystem" && continue
        [ -z "$line" ] && continue
        
        device=$(echo "$line" | awk '{print $1}')
        mount=$(echo "$line" | awk '{print $6}')
        usage=$(echo "$line" | awk '{print $5}' | sed 's/%//')
        
        echo "$device" | grep -qE "$exclude_patterns" && continue
        
        if [[ "$usage" =~ ^[0-9]+$ ]]; then
            if [ "$mount" = "/" ]; then
                target_device="$device"
                target_mount="$mount"
                target_usage=$usage
                debug_log "找到根分区: $device ($mount) 使用率: ${usage}%"
                echo "$target_usage|$target_device|$target_mount"
                return 0
            fi
        fi
    done < "$df_file"
    
    # 第二遍：找容量最大的分区
    local max_device=""
    local max_mount=""
    local max_usage=0
    local max_size=0
    
    while IFS= read -r line; do
        echo "$line" | grep -q "^Filesystem" && continue
        [ -z "$line" ] && continue
        
        device=$(echo "$line" | awk '{print $1}')
        mount=$(echo "$line" | awk '{print $6}')
        usage=$(echo "$line" | awk '{print $5}' | sed 's/%//')
        
        echo "$device" | grep -qE "$exclude_patterns" && continue
        
        size_raw=$(echo "$line" | awk '{print $2}')
        size_num=$(echo "$size_raw" | sed 's/G$/*1024/; s/M$/*1/; s/T$/*1024*1024/' | bc 2>/dev/null)
        [ -z "$size_num" ] && size_num=0
        
        if [[ "$usage" =~ ^[0-9]+$ ]] && [ "$size_num" -gt "$max_size" ]; then
            max_size=$size_num
            max_device="$device"
            max_mount="$mount"
            max_usage=$usage
        fi
    done < "$df_file"
    
    if [ -n "$max_device" ]; then
        target_device="$max_device"
        target_mount="$max_mount"
        target_usage=$max_usage
        debug_log "使用容量最大分区: $max_device ($max_mount) 使用率: ${max_usage}%"
    else
        while IFS= read -r line; do
            echo "$line" | grep -q "^Filesystem" && continue
            [ -z "$line" ] && continue
            device=$(echo "$line" | awk '{print $1}')
            mount=$(echo "$line" | awk '{print $6}')
            usage=$(echo "$line" | awk '{print $5}' | sed 's/%//')
            echo "$device" | grep -qE "$exclude_patterns" && continue
            if [[ "$usage" =~ ^[0-9]+$ ]]; then
                target_device="$device"
                target_mount="$mount"
                target_usage=$usage
                debug_log "使用第一个非虚拟分区: $device ($mount)"
                echo "$target_usage|$target_device|$target_mount"
                return 0
            fi
        done < "$df_file"
    fi
    
    echo "$target_usage|$target_device|$target_mount"
}

########################################
# 初始化 HTML 报告
########################################
cat > "$HTML_LOG" <<EOF
<!DOCTYPE html>
<html lang="zh-CN">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>${REPORT_TITLE} - $(date +%Y%m%d_%H%M%S)</title>
<style>
  * { margin: 0; padding: 0; box-sizing: border-box; }
  body {
    font-family: 'Segoe UI', Consolas, monospace;
    background: #f0f2f5;
    padding: 20px;
  }
  .container {
    max-width: 1400px;
    margin: 0 auto;
  }
  .header {
    background: linear-gradient(135deg, #1a1a2e 0%, #16213e 100%);
    color: #fff;
    padding: 20px 30px;
    border-radius: 12px;
    margin-bottom: 25px;
    box-shadow: 0 4px 15px rgba(0,0,0,0.1);
  }
  .header h1 { font-size: 24px; margin-bottom: 8px; }
  .header .subtitle { color: #a0a0a0; font-size: 14px; }
  .header .threshold-info {
    margin-top: 10px;
    font-size: 12px;
    color: #c0c0c0;
  }
  .alert-bar {
    background: #fff;
    border-radius: 10px;
    padding: 15px 20px;
    margin-bottom: 25px;
    box-shadow: 0 2px 8px rgba(0,0,0,0.08);
    border-left: 5px solid #e74c3c;
    display: none;
  }
  .alert-bar.show {
    display: flex;
    align-items: center;
    gap: 15px;
    flex-wrap: wrap;
  }
  .alert-icon { font-size: 28px; }
  .alert-text {
    flex: 1;
    font-size: 16px;
    font-weight: 500;
    color: #c0392b;
    white-space: pre-line;
  }
  .alert-close {
    cursor: pointer;
    font-size: 24px;
    color: #999;
    transition: color 0.2s;
  }
  .alert-close:hover { color: #333; }
  .stats {
    display: flex;
    gap: 20px;
    margin-bottom: 25px;
    flex-wrap: wrap;
  }
  .stat-card {
    background: #fff;
    border-radius: 10px;
    padding: 15px 25px;
    flex: 1;
    min-width: 120px;
    box-shadow: 0 2px 8px rgba(0,0,0,0.08);
    text-align: center;
  }
  .stat-card .number { font-size: 32px; font-weight: bold; }
  .stat-card .label { color: #666; margin-top: 5px; font-size: 13px; }
  .stat-card.critical .number { color: #e74c3c; }
  .stat-card.warning .number { color: #f39c12; }
  .nav {
    background: #fff;
    padding: 12px 20px;
    border-radius: 10px;
    margin-bottom: 25px;
    box-shadow: 0 2px 8px rgba(0,0,0,0.08);
    display: flex;
    flex-wrap: wrap;
    gap: 12px;
  }
  .nav a {
    color: #3498db;
    text-decoration: none;
    padding: 6px 14px;
    border-radius: 20px;
    transition: all 0.2s;
    font-size: 14px;
  }
  .nav a:hover { background: #3498db; color: #fff; }
  .server-card {
    background: #fff;
    border-radius: 12px;
    margin-bottom: 25px;
    overflow: hidden;
    box-shadow: 0 2px 12px rgba(0,0,0,0.1);
    transition: transform 0.2s;
  }
  .server-card:hover { transform: translateY(-2px); }
  .server-header {
    padding: 16px 24px;
    cursor: pointer;
    display: flex;
    justify-content: space-between;
    align-items: center;
    background: #f8f9fa;
    border-bottom: 1px solid #e9ecef;
    flex-wrap: wrap;
    gap: 10px;
  }
  .server-header.critical { background: #ffeaea; border-left: 4px solid #e74c3c; }
  .server-header.warning { background: #fff5e6; border-left: 4px solid #f39c12; }
  .server-title { font-size: 18px; font-weight: 600; }
  .server-title .host { color: #666; font-size: 14px; font-weight: normal; margin-left: 10px; }
  .warning-badges { display: flex; gap: 10px; flex-wrap: wrap; }
  .badge {
    padding: 4px 12px;
    border-radius: 20px;
    font-size: 12px;
    font-weight: 500;
  }
  .badge.critical { background: #e74c3c; color: #fff; }
  .badge.warning { background: #f39c12; color: #fff; }
  .server-content { padding: 20px 24px; display: none; border-top: none; }
  .server-content.open { display: block; }
  .metrics-row {
    display: flex;
    gap: 20px;
    margin-bottom: 25px;
    flex-wrap: wrap;
  }
  .metric {
    flex: 1;
    min-width: 100px;
    background: #f8f9fa;
    border-radius: 8px;
    padding: 12px 16px;
    text-align: center;
  }
  .metric .value { font-size: 24px; font-weight: bold; }
  .metric .value.critical { color: #e74c3c; }
  .metric .value.warning { color: #f39c12; }
  .metric .label { color: #666; font-size: 11px; margin-top: 5px; }
  .metric .sub { font-size: 10px; color: #999; margin-top: 3px; }
  .detail-section {
    margin-top: 15px;
    border: 1px solid #e9ecef;
    border-radius: 8px;
  }
  .detail-summary {
    padding: 12px 16px;
    background: #f8f9fa;
    cursor: pointer;
    font-weight: 600;
    border-radius: 8px;
  }
  .detail-summary:hover { background: #e9ecef; }
  .detail-content {
    padding: 16px;
    display: none;
    border-top: 1px solid #e9ecef;
    background: #fafafa;
    overflow-x: auto;
  }
  .detail-content.open { display: block; }
  pre {
    background: #2d2d2d;
    color: #f8f8f2;
    padding: 12px;
    border-radius: 6px;
    overflow-x: auto;
    font-size: 12px;
    margin: 0;
    white-space: pre-wrap;
    word-wrap: break-word;
  }
  .chart-container {
    background: #fff;
    border-radius: 12px;
    padding: 20px;
    margin-top: 30px;
    box-shadow: 0 2px 12px rgba(0,0,0,0.1);
  }
  .chart-container h3 { margin-bottom: 20px; color: #333; }
  canvas { max-height: 400px; width: 100%; }
  .footer {
    text-align: center;
    padding: 20px;
    color: #888;
    font-size: 12px;
  }
  .server-card.failed .server-header {
    background: #f5f5f5;
    border-left: 4px solid #999;
  }
  .failed-message {
    color: #999;
    font-style: italic;
  }
</style>
</head>
<body>
<div class="container">
  <div class="header">
    <h1>📊 ${REPORT_TITLE}</h1>
    <div class="subtitle" id="reportTime"></div>
    <div class="threshold-info">
      ⚙️ 告警阈值 | 🟡 警告 ≥ ${WARN_THRESHOLD}% | 🔴 严重 ≥ ${CRITICAL_THRESHOLD}% | 💾 磁盘告警 ≥ ${DISK_WARN_THRESHOLD}%
    </div>
  </div>
  <div id="alertPopup" class="alert-bar">
    <span class="alert-icon">⚠️</span>
    <span class="alert-text" id="alertText"></span>
    <span class="alert-close" onclick="document.getElementById('alertPopup').classList.remove('show')">&times;</span>
  </div>
  <div class="stats" id="statsContainer"></div>
  <div class="nav" id="navContainer"></div>
  <div id="serversContainer"></div>
  <div class="chart-container">
    <h3>📈 CPU / 内存 / 磁盘 使用率概览</h3>
    <canvas id="usageChart"></canvas>
  </div>
  <div class="footer">
    巡检脚本自动生成 | 生成时间: <span id="footerTime"></span>
  </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<script>
var WARN_THRESHOLD = ${WARN_THRESHOLD};
var CRITICAL_THRESHOLD = ${CRITICAL_THRESHOLD};
var DISK_WARN_THRESHOLD = ${DISK_WARN_THRESHOLD};
var DISK_CRITICAL_THRESHOLD = ${DISK_CRITICAL_THRESHOLD};

document.getElementById('reportTime').innerHTML = '生成时间: ' + new Date().toLocaleString('zh-CN');
document.getElementById('footerTime').innerHTML = new Date().toLocaleString('zh-CN');

var criticalServers = [];

function showAlert(message) {
  var popup = document.getElementById('alertPopup');
  document.getElementById('alertText').innerHTML = message;
  popup.classList.add('show');
}

function toggleServer(idx) {
  var content = document.getElementById('server_content_' + idx);
  if (content) content.classList.toggle('open');
}

function toggleDetail(detailId) {
  var el = document.getElementById(detailId);
  if (el) el.classList.toggle('open');
}

function escapeHtml(str) {
  if (!str) return '';
  return str.replace(/[&<>]/g, function(m) {
    if (m === '&') return '&amp;';
    if (m === '<') return '&lt;';
    if (m === '>') return '&gt;';
    return m;
  });
}

function renderReport(data) {
  var statsContainer = document.getElementById('statsContainer');
  var navContainer = document.getElementById('navContainer');
  var serversContainer = document.getElementById('serversContainer');
  
  var totalCpu = 0, totalMem = 0, totalDisk = 0;
  var criticalCount = 0, warningCount = 0;
  var successCount = 0;
  criticalServers = [];
  
  for (var i = 0; i < data.length; i++) {
    var s = data[i];
    if (s.status === 'success') {
      successCount++;
      totalCpu += s.cpuUsage;
      totalMem += s.memUsage;
      totalDisk += s.diskUsage;
      if (s.cpuUsage >= CRITICAL_THRESHOLD || s.memUsage >= CRITICAL_THRESHOLD || s.diskUsage >= DISK_CRITICAL_THRESHOLD) {
        criticalCount++;
        criticalServers.push({ name: s.name, host: s.host, cpu: s.cpuUsage, mem: s.memUsage, disk: s.diskUsage, diskDevice: s.diskDevice, diskMount: s.diskMount });
      } else if (s.cpuUsage >= WARN_THRESHOLD || s.memUsage >= WARN_THRESHOLD || s.diskUsage >= DISK_WARN_THRESHOLD) {
        warningCount++;
      }
    }
  }
  
  var avgCpu = successCount ? (totalCpu / successCount).toFixed(1) : 0;
  var avgMem = successCount ? (totalMem / successCount).toFixed(1) : 0;
  var avgDisk = successCount ? (totalDisk / successCount).toFixed(1) : 0;
  
  statsContainer.innerHTML = 
    '<div class="stat-card"><div class="number">' + data.length + '</div><div class="label">服务器总数</div></div>' +
    '<div class="stat-card"><div class="number">' + successCount + '</div><div class="label">采集成功</div></div>' +
    '<div class="stat-card ' + (criticalCount > 0 ? 'critical' : '') + '"><div class="number">' + criticalCount + '</div><div class="label">🔴 严重告警</div></div>' +
    '<div class="stat-card ' + (warningCount > 0 ? 'warning' : '') + '"><div class="number">' + warningCount + '</div><div class="label">🟡 预警</div></div>' +
    '<div class="stat-card"><div class="number">' + avgCpu + '%</div><div class="label">平均CPU使用率</div></div>' +
    '<div class="stat-card"><div class="number">' + avgMem + '%</div><div class="label">平均内存使用率</div></div>' +
    '<div class="stat-card"><div class="number">' + avgDisk + '%</div><div class="label">平均磁盘使用率</div></div>';
  
  var navHtml = '';
  var serversHtml = '';
  
  for (var idx = 0; idx < data.length; idx++) {
    var s = data[idx];
    
    if (s.status === 'failed') {
      navHtml += '<a href="#" onclick="document.getElementById(\'server_' + idx + '\').scrollIntoView({behavior:\'smooth\'}); return false;">' + escapeHtml(s.name) + ' (失败)</a>';
      serversHtml += '<div class="server-card failed" id="server_' + idx + '">' +
        '<div class="server-header" onclick="toggleServer(' + idx + ')">' +
        '<div class="server-title">' + escapeHtml(s.name) + ' <span class="host">' + escapeHtml(s.host) + '</span></div>' +
        '<div class="failed-message">采集失败</div>' +
        '</div>' +
        '<div class="server-content" id="server_content_' + idx + '">' +
        '<div class="detail-section">' +
        '<div class="detail-summary">❌ 采集失败信息</div>' +
        '<div class="detail-content open"><pre>' + escapeHtml(s.errorMsg) + '</pre></div>' +
        '</div>' +
        '</div></div>';
      continue;
    }
    
    var headerClass = '';
    if (s.cpuUsage >= CRITICAL_THRESHOLD || s.memUsage >= CRITICAL_THRESHOLD || s.diskUsage >= DISK_CRITICAL_THRESHOLD) headerClass = 'critical';
    else if (s.cpuUsage >= WARN_THRESHOLD || s.memUsage >= WARN_THRESHOLD || s.diskUsage >= DISK_WARN_THRESHOLD) headerClass = 'warning';
    
    var cpuClass = s.cpuUsage >= CRITICAL_THRESHOLD ? 'critical' : (s.cpuUsage >= WARN_THRESHOLD ? 'warning' : '');
    var memClass = s.memUsage >= CRITICAL_THRESHOLD ? 'critical' : (s.memUsage >= WARN_THRESHOLD ? 'warning' : '');
    var diskClass = s.diskUsage >= DISK_CRITICAL_THRESHOLD ? 'critical' : (s.diskUsage >= DISK_WARN_THRESHOLD ? 'warning' : '');
    
    navHtml += '<a href="#" onclick="document.getElementById(\'server_' + idx + '\').scrollIntoView({behavior:\'smooth\'}); return false;">' + escapeHtml(s.name) + '</a>';
    
    var diskDisplay = s.diskUsage + '%';
    if (s.diskDevice && s.diskDevice !== '') {
      var shortDevice = s.diskDevice.split('/').pop();
      diskDisplay = diskDisplay + '<div class="sub">' + escapeHtml(shortDevice) + (s.diskMount && s.diskMount !== '/' ? ' (' + escapeHtml(s.diskMount) + ')' : '') + '</div>';
    }
    
    serversHtml += '<div class="server-card" id="server_' + idx + '">' +
      '<div class="server-header ' + headerClass + '" onclick="toggleServer(' + idx + ')">' +
      '<div class="server-title">' + escapeHtml(s.name) + ' <span class="host">' + escapeHtml(s.host) + '</span></div>' +
      '<div class="warning-badges">' +
      (s.cpuUsage >= CRITICAL_THRESHOLD ? '<span class="badge critical">🔴 CPU≥' + CRITICAL_THRESHOLD + '%</span>' : (s.cpuUsage >= WARN_THRESHOLD ? '<span class="badge warning">🟡 CPU≥' + WARN_THRESHOLD + '%</span>' : '')) +
      (s.memUsage >= CRITICAL_THRESHOLD ? '<span class="badge critical">🔴 内存≥' + CRITICAL_THRESHOLD + '%</span>' : (s.memUsage >= WARN_THRESHOLD ? '<span class="badge warning">🟡 内存≥' + WARN_THRESHOLD + '%</span>' : '')) +
      (s.diskUsage >= DISK_CRITICAL_THRESHOLD ? '<span class="badge critical">🔴 磁盘≥' + DISK_CRITICAL_THRESHOLD + '%</span>' : (s.diskUsage >= DISK_WARN_THRESHOLD ? '<span class="badge warning">🟡 磁盘≥' + DISK_WARN_THRESHOLD + '%</span>' : '')) +
      '</div></div>' +
      '<div class="server-content" id="server_content_' + idx + '">' +
      '<div class="metrics-row">' +
      '<div class="metric"><div class="value ' + cpuClass + '">' + s.cpuUsage + '%</div><div class="label">CPU使用率</div></div>' +
      '<div class="metric"><div class="value ' + memClass + '">' + s.memUsage + '%</div><div class="label">内存使用率</div></div>' +
      '<div class="metric"><div class="value ' + diskClass + '">' + diskDisplay + '</div><div class="label">磁盘使用率</div></div>' +
      '<div class="metric"><div class="value">' + s.loadAvg + '</div><div class="label">负载(1min)</div></div>' +
      '<div class="metric"><div class="value">' + s.cores + '</div><div class="label">CPU核心数</div></div>' +
      '</div>' +
      '<div class="detail-section">' +
      '<div class="detail-summary" onclick="toggleDetail(\'detail_basic_' + idx + '\')">📋 基础系统信息</div>' +
      '<div class="detail-content" id="detail_basic_' + idx + '"><pre>' + escapeHtml(s.basicInfo) + '</pre></div>' +
      '</div>' +
      '<div class="detail-section">' +
      '<div class="detail-summary" onclick="toggleDetail(\'detail_service_' + idx + '\')">🔧 服务与数据库检测</div>' +
      '<div class="detail-content" id="detail_service_' + idx + '"><pre>' + escapeHtml(s.serviceInfo) + '</pre></div>' +
      '</div>' +
      '<div class="detail-section">' +
      '<div class="detail-summary" onclick="toggleDetail(\'detail_top_' + idx + '\')">📊 TOP进程（按CPU排序前20）</div>' +
      '<div class="detail-content" id="detail_top_' + idx + '"><pre>' + escapeHtml(s.topInfo) + '</pre></div>' +
      '</div>' +
      '</div></div>';
  }
  
  navContainer.innerHTML = navHtml;
  serversContainer.innerHTML = serversHtml;
  
  var successData = [];
  for (var i = 0; i < data.length; i++) {
    if (data[i].status === 'success') successData.push(data[i]);
  }
  
  var labels = successData.map(function(s) { return s.name; });
  var cpuData = successData.map(function(s) { return s.cpuUsage; });
  var memData = successData.map(function(s) { return s.memUsage; });
  var diskData = successData.map(function(s) { return s.diskUsage; });
  
  if (labels.length > 0) {
    new Chart(document.getElementById('usageChart'), {
      type: 'bar',
      data: {
        labels: labels,
        datasets: [
          { label: 'CPU 使用率 (%)', data: cpuData, backgroundColor: 'rgba(231, 76, 60, 0.7)', borderColor: '#c0392b', borderWidth: 1 },
          { label: '内存使用率 (%)', data: memData, backgroundColor: 'rgba(52, 152, 219, 0.7)', borderColor: '#2980b9', borderWidth: 1 },
          { label: '磁盘使用率 (%)', data: diskData, backgroundColor: 'rgba(46, 204, 113, 0.7)', borderColor: '#27ae60', borderWidth: 1 }
        ]
      },
      options: {
        responsive: true,
        maintainAspectRatio: true,
        scales: { y: { beginAtZero: true, max: 100, ticks: { stepSize: 10 } } },
        plugins: { tooltip: { callbacks: { label: function(ctx) { return ctx.dataset.label + ': ' + ctx.raw + '%'; } } } }
      }
    });
  } else {
    document.getElementById('usageChart').parentElement.innerHTML = '<div style="text-align:center;padding:50px;color:#999;">暂无成功采集的数据，无法生成图表</div>';
  }
  
  if (criticalServers.length > 0) {
    var alertMsg = '';
    for (var i = 0; i < criticalServers.length; i++) {
      var s = criticalServers[i];
      if (s.cpu >= CRITICAL_THRESHOLD) alertMsg += '• ' + s.name + '(' + s.host + ') CPU使用率 ' + s.cpu + '%\n';
      if (s.mem >= CRITICAL_THRESHOLD) alertMsg += '• ' + s.name + '(' + s.host + ') 内存使用率 ' + s.mem + '%\n';
      if (s.disk >= DISK_CRITICAL_THRESHOLD) alertMsg += '• ' + s.name + '(' + s.host + ') 磁盘使用率 ' + s.disk + '% (设备:' + s.diskDevice + ' 挂载:' + s.diskMount + ')\n';
    }
    showAlert('⚠️ 以下服务器资源使用率超过阈值：\n' + alertMsg);
  }
}
</script>
EOF

########################################
# 主循环：逐台服务器巡检并收集数据
########################################
REPORT_DATA=""
FAIL_COUNT=0
SUCCESS_COUNT=0

for ITEM in "${SERVERS[@]}"; do
  IFS="|" read -r NAME HOST USER PASS <<< "$ITEM"
  
  info_log "正在巡检：$NAME ($HOST)"
  
  # 上传采集脚本
  if ! upload_collect "$HOST" "$USER" "$PASS"; then
    error_log "上传脚本失败：$NAME ($HOST)"
    FAIL_ITEM="{\"name\":\"$NAME\",\"host\":\"$HOST\",\"status\":\"failed\",\"errorMsg\":\"上传采集脚本失败，请检查网络连接和SSH/SCP权限\"}"
    if [ -z "$REPORT_DATA" ]; then
      REPORT_DATA="$FAIL_ITEM"
    else
      REPORT_DATA="$REPORT_DATA,$FAIL_ITEM"
    fi
    ((FAIL_COUNT++))
    if [ "$CONTINUE_ON_ERROR" = false ]; then
      exit 1
    fi
    continue
  fi
  
  # 执行采集脚本
  if ! run_collect "$HOST" "$USER" "$PASS"; then
    error_log "执行采集失败：$NAME ($HOST)"
    FAIL_ITEM="{\"name\":\"$NAME\",\"host\":\"$HOST\",\"status\":\"failed\",\"errorMsg\":\"执行采集脚本失败，请检查目标服务器环境\"}"
    if [ -z "$REPORT_DATA" ]; then
      REPORT_DATA="$FAIL_ITEM"
    else
      REPORT_DATA="$REPORT_DATA,$FAIL_ITEM"
    fi
    ((FAIL_COUNT++))
    if [ "$CONTINUE_ON_ERROR" = false ]; then
      exit 1
    fi
    continue
  fi
  
  # 拉取采集结果到临时目录
  SERVER_TEMP_DIR="$LOCAL_TEMP_BASE/${HOST}"
  mkdir -p "$SERVER_TEMP_DIR"
  if ! pull_files "$HOST" "$USER" "$PASS" "$SERVER_TEMP_DIR"; then
    error_log "拉取结果失败：$NAME ($HOST)"
    FAIL_ITEM="{\"name\":\"$NAME\",\"host\":\"$HOST\",\"status\":\"failed\",\"errorMsg\":\"拉取采集结果失败，请检查SCP权限\"}"
    if [ -z "$REPORT_DATA" ]; then
      REPORT_DATA="$FAIL_ITEM"
    else
      REPORT_DATA="$REPORT_DATA,$FAIL_ITEM"
    fi
    ((FAIL_COUNT++))
    if [ "$CONTINUE_ON_ERROR" = false ]; then
      exit 1
    fi
    continue
  fi
  
  COLLECT_DIR="$SERVER_TEMP_DIR/health_collect"
  
  # 检查采集是否成功
  if [ ! -d "$COLLECT_DIR" ] || [ ! -f "$COLLECT_DIR/hostname.txt" ]; then
    error_log "采集数据不完整：$NAME ($HOST)"
    FAIL_ITEM="{\"name\":\"$NAME\",\"host\":\"$HOST\",\"status\":\"failed\",\"errorMsg\":\"采集数据不完整，缺少必要文件\"}"
    if [ -z "$REPORT_DATA" ]; then
      REPORT_DATA="$FAIL_ITEM"
    else
      REPORT_DATA="$REPORT_DATA,$FAIL_ITEM"
    fi
    ((FAIL_COUNT++))
    if [ "$CONTINUE_ON_ERROR" = false ]; then
      exit 1
    fi
    continue
  fi
  
  # 执行服务检测
  info_log "检测 $NAME ($HOST) 服务状态..."
  CHECK_CMD=$(build_service_check_cmd "$NAME")
  
  SERVICE_CHECK_RESULT=$(expect <<EOF 2>/dev/null
set timeout 30
spawn ssh -o StrictHostKeyChecking=no $USER@$HOST "$CHECK_CMD"
expect {
    "*yes/no*" { send "yes\r"; exp_continue }
    "*assword*" { send "$PASS\r"; exp_continue }
    eof
}
EOF
)
  
  # 收集基础信息
  BASIC_INFO=$(cat "$COLLECT_DIR/hostname.txt" 2>/dev/null; echo
    echo "----- IP地址 -----"; cat "$COLLECT_DIR/ip_addr.txt" 2>/dev/null
    echo "----- 系统时间 -----"; cat "$COLLECT_DIR/datetime.txt" 2>/dev/null
    echo "----- 运行时长 -----"; cat "$COLLECT_DIR/uptime.txt" 2>/dev/null
    echo "----- 内核版本 -----"; cat "$COLLECT_DIR/kernel.txt" 2>/dev/null
    echo "----- 系统架构 -----"; cat "$COLLECT_DIR/arch.txt" 2>/dev/null
    echo "----- 时间同步 -----"; cat "$COLLECT_DIR/timedatectl.txt" 2>/dev/null
    echo "----- 登录用户 -----"; cat "$COLLECT_DIR/who.txt" 2>/dev/null
    echo "----- 系统版本 -----"; cat "$COLLECT_DIR/release.txt" 2>/dev/null
    echo "----- CPU信息 -----"; cat "$COLLECT_DIR/lscpu.txt" 2>/dev/null
    echo "----- 内存信息(free -h) -----"; cat "$COLLECT_DIR/free_h.txt" 2>/dev/null
    echo "----- 磁盘信息(df -h) -----"; cat "$COLLECT_DIR/df_h.txt" 2>/dev/null)
  
  # 收集服务信息
  SERVICE_INFO=""
  if [ -n "$SERVICE_CHECK_RESULT" ] && [ "$SERVICE_CHECK_RESULT" != "" ]; then
    SERVICE_INFO="$SERVICE_CHECK_RESULT"
  else
    if [ "$SHOW_NO_SERVICES" = true ]; then
      SERVICE_INFO="无应用服务运行"
    fi
  fi
  
  SERVICE_INFO="$SERVICE_INFO"$'\n\n'"===== 端口监听 ====="$'\n'
  SERVICE_INFO="$SERVICE_INFO$(cat "$COLLECT_DIR/ports.txt" 2>/dev/null)"
  
  # 收集TOP信息
  TOP_INFO=$(cat "$COLLECT_DIR/top.txt" 2>/dev/null)
  
  # 计算内存使用率
  FREE_M_FILE="$COLLECT_DIR/free_m.txt"
  MEM_PCT=$(awk '/Mem:/ {if($2>0){printf "%.1f", $3*100/$2}else{print "0.0"}}' "$FREE_M_FILE" 2>/dev/null)
  [ -z "$MEM_PCT" ] && MEM_PCT="0.0"
  
  # ========== CPU 核心数获取逻辑（修复版） ==========
  UPTIME_FILE="$COLLECT_DIR/uptime.txt"
  LCPU_FILE="$COLLECT_DIR/lscpu.txt"
  
  # 获取负载
  LOAD1=$(awk -F'load average: ' '{print $2}' "$UPTIME_FILE" 2>/dev/null | cut -d',' -f1 | tr -d ' ')
  [ -z "$LOAD1" ] && LOAD1=0
  
  # 获取CPU核心数 - 多种方法
  CORES=""
  
  # 方法1: 从 /proc/cpuinfo 获取 processor 数量
  if [ -f "$COLLECT_DIR/cpuinfo.txt" ]; then
    CORES=$(grep -c "^processor" "$COLLECT_DIR/cpuinfo.txt" 2>/dev/null)
    debug_log "方法1(cpuinfo): 核心数=$CORES"
  fi
  
  # 方法2: 从 nproc 获取
  if [ -z "$CORES" ] || [ "$CORES" -eq 0 ]; then
    if [ -f "$COLLECT_DIR/nproc.txt" ]; then
        CORES=$(cat "$COLLECT_DIR/nproc.txt" 2>/dev/null)
        debug_log "方法2(nproc): 核心数=$CORES"
    fi
  fi
  
  # 方法3: 从 lscpu 的 CPU(s) 获取
  if [ -z "$CORES" ] || [ "$CORES" -eq 0 ]; then
    CORES=$(grep -E "^CPU\(s\):" "$LCPU_FILE" 2>/dev/null | head -1 | awk '{print $2}')
    debug_log "方法3(lscpu CPU(s)): 核心数=$CORES"
  fi
  
  # 方法4: 从 lscpu 计算物理核心数
  if [ -z "$CORES" ] || [ "$CORES" -eq 0 ]; then
    CORES_PER_SOCKET=$(grep -E "^Core\(s\) per socket:" "$LCPU_FILE" 2>/dev/null | awk '{print $4}')
    SOCKETS=$(grep -E "^Socket\(s\):" "$LCPU_FILE" 2>/dev/null | awk '{print $2}')
    if [ -n "$CORES_PER_SOCKET" ] && [ -n "$SOCKETS" ] && [ "$CORES_PER_SOCKET" -gt 0 ] && [ "$SOCKETS" -gt 0 ]; then
        CORES=$((CORES_PER_SOCKET * SOCKETS))
        debug_log "方法4(物理核心计算): ${CORES_PER_SOCKET} * ${SOCKETS} = ${CORES}"
    fi
  fi
  
  # 方法5: 默认值
  if [ -z "$CORES" ] || [ "$CORES" -eq 0 ]; then
    CORES=1
    debug_log "方法5(默认): 核心数=1"
  fi
  
  info_log "最终 CPU 核心数: $CORES (负载: $LOAD1)"
  
  # 计算CPU使用率（负载/核心数*100，上限100%）
  CPU_PCT=$(awk -v l="$LOAD1" -v c="$CORES" 'BEGIN{if(c<=0)c=1; p=l/c*100; if(p>100)p=100; if(p<0)p=0; printf "%.1f", p}')
  
  # 计算磁盘使用率
  DF_H_FILE="$COLLECT_DIR/df_h.txt"
  DISK_RESULT=$(get_main_disk_info "$DF_H_FILE")
  DISK_PCT=$(echo "$DISK_RESULT" | cut -d'|' -f1)
  DISK_DEVICE=$(echo "$DISK_RESULT" | cut -d'|' -f2)
  DISK_MOUNT=$(echo "$DISK_RESULT" | cut -d'|' -f3)
  
  if [ -z "$DISK_PCT" ] || [ "$DISK_PCT" = "0" ]; then
    DISK_RESULT=$(awk '!/^Filesystem/ && !/tmpfs/ && !/devtmpfs/ && !/overlay/ && !/udev/ {gsub(/%/,"",$5); print $5"|"$1"|"$6; exit}' "$DF_H_FILE" 2>/dev/null)
    DISK_PCT=$(echo "$DISK_RESULT" | cut -d'|' -f1)
    DISK_DEVICE=$(echo "$DISK_RESULT" | cut -d'|' -f2)
    DISK_MOUNT=$(echo "$DISK_RESULT" | cut -d'|' -f3)
  fi
  
  [ -z "$DISK_PCT" ] && DISK_PCT="0"
  [ -z "$DISK_DEVICE" ] && DISK_DEVICE=""
  [ -z "$DISK_MOUNT" ] && DISK_MOUNT=""
  
  # 转义JSON中的特殊字符
  BASIC_INFO_ESCAPED=$(printf "%s" "$BASIC_INFO" | sed 's/\\/\\\\/g; s/"/\\"/g' | awk '{printf "%s\\n", $0}')
  SERVICE_INFO_ESCAPED=$(printf "%s" "$SERVICE_INFO" | sed 's/\\/\\\\/g; s/"/\\"/g' | awk '{printf "%s\\n", $0}')
  TOP_INFO_ESCAPED=$(printf "%s" "$TOP_INFO" | sed 's/\\/\\\\/g; s/"/\\"/g' | awk '{printf "%s\\n", $0}')
  
  info_log "采集成功：$NAME ($HOST) | CPU:${CPU_PCT}% (负载:${LOAD1} / 核心:${CORES}) MEM:${MEM_PCT}% DISK:${DISK_PCT}%"
  
  # 构建JSON对象
  JSON_ITEM="{\"name\":\"$NAME\",\"host\":\"$HOST\",\"status\":\"success\",\"cpuUsage\":$CPU_PCT,\"memUsage\":$MEM_PCT,\"diskUsage\":$DISK_PCT,\"diskDevice\":\"$DISK_DEVICE\",\"diskMount\":\"$DISK_MOUNT\",\"loadAvg\":\"$LOAD1\",\"cores\":$CORES,\"basicInfo\":\"$BASIC_INFO_ESCAPED\",\"serviceInfo\":\"$SERVICE_INFO_ESCAPED\",\"topInfo\":\"$TOP_INFO_ESCAPED\"}"
  
  if [ -z "$REPORT_DATA" ]; then
    REPORT_DATA="$JSON_ITEM"
  else
    REPORT_DATA="$REPORT_DATA,$JSON_ITEM"
  fi
  ((SUCCESS_COUNT++))
  
done

# 生成JSON数据并写入HTML
cat >> "$HTML_LOG" <<EOF
<script>
var reportData = [$REPORT_DATA];
renderReport(reportData);
</script>
</body>
</html>
EOF

# 清理临时目录
cleanup

echo ""
echo "==============================================="
echo "巡检完成！"
echo "==============================================="
echo "文件模式: $FILE_MODE"
echo "报告存放目录: $REPORT_DIR"
echo "HTML 报告: $HTML_LOG"
echo "服务器总数: ${#SERVERS[@]}"
echo "采集成功: $SUCCESS_COUNT"
echo "采集失败: $FAIL_COUNT"
echo "==============================================="